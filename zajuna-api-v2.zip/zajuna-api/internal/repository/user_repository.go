package repository

import (
	"zajunaApi/internal/models"

	"gorm.io/gorm"
)

type UserRepository struct {
	DB *gorm.DB
}

func NewUserRepository(db *gorm.DB) *UserRepository {
	return &UserRepository{DB: db}
}

// FindByFilters busca usuarios con filtros dinámicos
func (r *UserRepository) FindByFilters(filters map[string]string, page, limit int) ([]models.User, int64, error) {
	var users []models.User
	var total int64

	query := r.DB.Model(&models.User{})

	// Aplicar filtros solo si vienen con datos
	if firstname := filters["firstname"]; firstname != "" {
		query = query.Where("firstname ILIKE ?", "%"+firstname+"%")
	}
	if lastname := filters["lastname"]; lastname != "" {
		query = query.Where("lastname ILIKE ?", "%"+lastname+"%")
	}
	if username := filters["username"]; username != "" {
		query = query.Where("username ILIKE ?", "%"+username+"%")
	}
	if email := filters["email"]; email != "" {
		query = query.Where("email ILIKE ?", "%"+email+"%")
	}

	// Contar total antes de paginar
	query.Count(&total)

	// Aplicar paginación
	offset := (page - 1) * limit
	if err := query.Offset(offset).Limit(limit).Find(&users).Error; err != nil {
		return nil, 0, err
	}

	return users, total, nil
}
